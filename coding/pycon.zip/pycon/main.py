import json
import sys
import os
def newcon():
    print("You MUST use a unique display name for multiples of a first name")
    print("If you dont want to use a field just press enter")

    dispname = input("Enter a display name: ")
    fname = input("Enter first name: ")
    lname = input("Enter last name: ")
    emails = []
    emails.append(input("Enter a school/work email: "))
    emails.append(input("Enter a personal email address: "))

    json_file = open('contacts.json')
    passfile = json.load(json_file)
    if dispname == "":
        passfile.update({fname: {
            "name": fname + " " + lname,
            "email": emails
        }})
    else:
          passfile.update({dispname: {
            "name": fname + " " + lname,
            "email": emails
        }})

    with open("contacts.json", 'w') as file:
            json.dump(passfile, file, indent=6)
    restart_program()

def readcon():
      name = input("Enter the first name or display name as you entered it: ")
      json_file = open('contacts.json')
      file = json.load(json_file)
      entry = file.get(name)
      entry_list = list(entry.values())
      print(entry_list[0])
      i = 0
      while i < len(entry_list[1]):
            print(entry_list[1][i])
            i += 1
      restart_program()

option = input("Enter VIEW or ADD to select what you want to do: ")
if option == "VIEW":
      readcon()
if option == "ADD":
      newcon()

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)